public class CreateFileOrFolder
{
    static void Main()
    {
        // Specify a name for your top-level folder.
        string folderName = @"c:\C#Solution3";
        // Use Combine to add the file name to the path.
        pathString = System.IO.Path.Combine(pathString, fileName);
        // Verify the path that you have constructed.
        Console.WriteLine("Path to my file: {0}\n", pathString);

        // Check that the file doesn't already exist. If it doesn't exist, create file
        if (!System.IO.File.Exists(pathString))
        {
            using (System.IO.FileStream fs = System.IO.File.Create(pathString))
            {
                // Write file using StreamWriter  
            using (StreamWriter writer = new StreamWriter(pathString))  
            {  
                writer.WriteLine("My name is Ropafadzo");  
                writer.WriteLine("I come from Harare");  
                writer.WriteLine("I am a software developer.");  
            }
        }
        else
        {
            Console.WriteLine("File \"{0}\" already exists.", fileName);
            return;
        }
        }
        // Read and display the data from your file.
        string GetLine(string fileName, int line)
        {
            using (var sr = new StreamReader(fileName)) {
            for (int i = 1; i < line; i++)
            sr.ReadLine();
            return sr.ReadLine();
   }
        }
    }
}